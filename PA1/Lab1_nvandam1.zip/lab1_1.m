ur5 = ur5_interface()
ur5.move_joints(ur5.home,10)